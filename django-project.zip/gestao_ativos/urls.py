from django.contrib import admin
from django.urls import path
from equipamentos import views

urlpatterns = [
    path("admin/", admin.site.urls),

    # Tela 1: Listagem
    path('', views.listagem_equipamentos, name='listagem_equipamentos'),

    # Tela 2: Cadastro
    path('cadastrar/', views.cadastrar_equipamento, name='cadastrar_equipamento'),

    # Tela 3: Detalhes
    path('equipamento/<int:id>/', views.detalhe_equipamento, name='detalhe_equipamento'),

    # Editar
    path('equipamento/<int:id>/editar/', views.editar_equipamento, name='editar_equipamento'),

    # Excluir
    path('equipamento/<int:id>/excluir/', views.excluir_equipamento, name='excluir_equipamento'),

    # Painel de Controle
    path('painel/', views.painel_controle, name='painel_controle'),
]