from django.shortcuts import render, redirect, get_object_or_404
from .models import Equipamento
from .forms import EquipamentoForm


# Tela 1: Listagem/Dashboard
def listagem_equipamentos(request):
    equipamentos = Equipamento.objects.all()
    contexto = {'equipamentos': equipamentos}
    return render(request, 'equipamentos/listagem.html', contexto)


# Tela 2: Cadastro
def cadastrar_equipamento(request):
    if request.method == 'POST':
        form = EquipamentoForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('listagem_equipamentos')
    else:
        form = EquipamentoForm()
    return render(request, 'equipamentos/cadastrar.html', {'form': form})


# Tela 3: Detalhes
def detalhe_equipamento(request, id):
    equipamento = get_object_or_404(Equipamento, id=id)
    return render(request, 'equipamentos/detalhe.html', {'equipamento': equipamento})


# extra: Editar
def editar_equipamento(request, id):
    equipamento = get_object_or_404(Equipamento, id=id)

    if request.method == 'POST':
        form = EquipamentoForm(request.POST, instance=equipamento)
        if form.is_valid():
            form.save()
            return redirect('listagem_equipamentos')
    else:
        form = EquipamentoForm(instance=equipamento)

    return render(request, 'equipamentos/editar.html', {'form': form, 'equipamento': equipamento})


# extra: Excluir
def excluir_equipamento(request, id):
    equipamento = get_object_or_404(Equipamento, id=id)
    equipamento.delete()
    return redirect('listagem_equipamentos')


# extra: Painel de Controle
def painel_controle(request):
    equipamentos = Equipamento.objects.all()
    equipamentos_fora_de_uso = equipamentos.filter(em_uso=False)

    contexto = {
        'total_equipamentos': equipamentos.count(),
        'total_fora_de_uso': equipamentos_fora_de_uso.count(),
        'lista_fora_de_uso': equipamentos_fora_de_uso,
    }
    return render(request, 'equipamentos/painel.html', contexto)